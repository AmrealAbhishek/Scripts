// Connect to Socket.io
const socket = io();

// DOM elements
const statusCard = document.getElementById('status-card');
const qrcodeContainer = document.getElementById('qrcode-container');
const sendBtn = document.getElementById('send-btn');
const progressContainer = document.getElementById('progress-container');
const progressBar = document.getElementById('progress-bar');
const progressStatus = document.getElementById('progress-status');
const progressLog = document.getElementById('progress-log');

// Variables to track QR code state
let lastQrCode = null;
let qrCodeTimeoutId = null;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 3;

// Socket.io event handlers

// Handle QR code updates
socket.on('qrCode', (data) => {
    if (!data.qrCode) return;
    
    // Check if the QR code is different from the last one we received
    const isNewQrCode = data.qrCode !== lastQrCode;
    lastQrCode = data.qrCode;
    
    if (qrcodeContainer) {
        qrcodeContainer.innerHTML = `<img src="${data.qrCode}" alt="WhatsApp QR Code" class="img-fluid">`;
        
        // Add a 'Scan me' message
        const scanMessage = document.createElement('p');
        scanMessage.className = 'text-center mt-2 fw-bold text-primary';
        scanMessage.textContent = 'Scan with WhatsApp to connect';
        qrcodeContainer.appendChild(scanMessage);
        
        // If this is a new QR code (not just a reconnection), show a notification to alert the user
        if (isNewQrCode) {
            showNotification('New QR Code Available', 'Please scan the new QR code with WhatsApp.');
            
            // Create a QR code expiry timer
            if (qrCodeTimeoutId) clearTimeout(qrCodeTimeoutId);
            
            // Add expiry countdown
            const countdownEl = document.createElement('div');
            countdownEl.className = 'text-center mt-2 qr-countdown';
            qrcodeContainer.appendChild(countdownEl);
            
            let countdown = 60; // QR codes typically expire in 60 seconds
            updateCountdown();
            
            function updateCountdown() {
                countdownEl.textContent = `QR code expires in ${countdown} seconds`;
                if (countdown > 0) {
                    countdown--;
                    setTimeout(updateCountdown, 1000);
                } else {
                    countdownEl.textContent = 'QR code expired. Waiting for new code...';
                }
            }
            
            // Auto-reload the page if the QR code isn't scanned after 65 seconds
            qrCodeTimeoutId = setTimeout(() => {
                if (!document.hidden && reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
                    reconnectAttempts++;
                    socket.emit('requestNewQrCode');
                    
                    // Add a message that we're requesting a new QR code
                    const refreshMessage = document.createElement('div');
                    refreshMessage.className = 'alert alert-info mt-3';
                    refreshMessage.textContent = 'Requesting a new QR code...';
                    qrcodeContainer.appendChild(refreshMessage);
                } else if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
                    // If we've tried too many times, reload the page
                    location.reload();
                    reconnectAttempts = 0;
                }
            }, 65000);
        }
    }
});

// Handle client status updates
socket.on('clientStatus', (data) => {
    if (statusCard) {
        // Reset reconnect attempts when status changes
        reconnectAttempts = 0;
        
        if (data.status === 'ready' || data.status === 'authenticated') {
            lastQrCode = null; // Reset QR code state
            if (qrCodeTimeoutId) {
                clearTimeout(qrCodeTimeoutId);
                qrCodeTimeoutId = null;
            }
            
            statusCard.innerHTML = `
                <div class="alert alert-success">
                    <strong>Connected to WhatsApp!</strong> Ready to send messages.
                </div>
            `;
            if (sendBtn) {
                sendBtn.disabled = false;
            }
            
            // Show a notification if the user is not on the page
            if (document.hidden) {
                showNotification('WhatsApp Connected', 'Your WhatsApp is now connected and ready to send messages.');
            }
        } else if (data.status === 'disconnected') {
            const reason = data.reason || '';
            const wasLogout = reason.includes('LOGOUT');
            
            statusCard.innerHTML = `
                <div class="alert alert-danger">
                    <strong>Disconnected from WhatsApp.</strong> ${reason}
                </div>
                <div id="qrcode-container">
                    <p class="text-muted">Reconnecting...</p>
                </div>
            `;
            if (sendBtn) {
                sendBtn.disabled = true;
            }
            
            // If this was a logout (not a connection error), show notification and reload the page
            if (wasLogout) {
                showNotification('WhatsApp Logged Out', 'You have been logged out. Refreshing page to show new QR code.');
                
                // Give the user a chance to see the notification, then reload
                setTimeout(() => {
                    location.reload();
                }, 2000);
            }
        } else if (data.status === 'authFailure') {
            statusCard.innerHTML = `
                <div class="alert alert-danger">
                    <strong>Authentication failed.</strong> ${data.message || 'Please try scanning the QR code again.'}
                </div>
                <div id="qrcode-container">
                    <p class="text-muted">Waiting for QR code...</p>
                </div>
            `;
            if (sendBtn) {
                sendBtn.disabled = true;
            }
            
            // Show notification about auth failure
            showNotification('Authentication Failed', 'Please scan the QR code again when it appears.');
        }
    }
});

// Handle sending progress updates
socket.on('sendingProgress', (data) => {
    // Show progress container if it's hidden
    if (progressContainer.classList.contains('d-none')) {
        progressContainer.classList.remove('d-none');
    }
    
    // Handle started status
    if (data.status === 'started') {
        progressStatus.className = 'alert alert-info';
        progressStatus.textContent = `Started sending messages to ${data.total} contacts...`;
        progressBar.style.width = '0%';
        progressBar.textContent = '0%';
        progressLog.innerHTML = ''; // Clear previous logs
        
        // Disable the send button while sending
        if (sendBtn) {
            sendBtn.disabled = true;
        }
    }
    
    // Handle sending status
    else if (data.status === 'sending') {
        const percent = Math.round((data.current / data.total) * 100);
        progressBar.style.width = `${percent}%`;
        progressBar.textContent = `${percent}%`;
        progressStatus.className = 'alert alert-info';
        progressStatus.textContent = `Sending message ${data.current} of ${data.total}...`;
        
        // Add log entry
        const logEntry = document.createElement('div');
        logEntry.className = 'log-entry info';
        logEntry.textContent = `Sending to ${data.phone}...`;
        progressLog.appendChild(logEntry);
        progressLog.scrollTop = progressLog.scrollHeight;
    }
    
    // Handle error status
    else if (data.status === 'error') {
        const logEntry = document.createElement('div');
        logEntry.className = 'log-entry error';
        logEntry.textContent = `Error sending to ${data.phone}: ${data.error}`;
        progressLog.appendChild(logEntry);
        progressLog.scrollTop = progressLog.scrollHeight;
    }
    
    // Handle completed status
    else if (data.status === 'completed') {
        const percent = 100;
        progressBar.style.width = `${percent}%`;
        progressBar.textContent = `${percent}%`;
        
        progressStatus.className = 'alert alert-success';
        progressStatus.textContent = `Completed! Successfully sent ${data.success} out of ${data.total} messages.`;
        
        const logEntry = document.createElement('div');
        logEntry.className = 'log-entry success';
        logEntry.textContent = `✓ Completed sending messages! Success: ${data.success}, Failed: ${data.failure}`;
        progressLog.appendChild(logEntry);
        progressLog.scrollTop = progressLog.scrollHeight;
        
        // Re-enable the send button
        if (sendBtn) {
            sendBtn.disabled = false;
        }
        
        // Show notification if user is not on the page
        if (document.hidden) {
            showNotification('Messages Sent', `Completed sending messages: ${data.success} successful, ${data.failure} failed.`);
        }
    }
});

// Form submission handlers
document.addEventListener('DOMContentLoaded', function() {
    // Handle send messages form submission
    const sendMessagesForm = document.getElementById('send-messages-form');
    if (sendMessagesForm) {
        sendMessagesForm.addEventListener('submit', function(e) {
            if (!confirm('Are you sure you want to send messages to all contacts?')) {
                e.preventDefault();
            }
        });
    }
    
    // Request a fresh QR code when the page loads
    if (!isClientReady) {
        socket.emit('requestNewQrCode');
    }
    
    // Setup visibility change detection
    document.addEventListener('visibilitychange', function() {
        if (!document.hidden && !isClientReady) {
            // If user returns to the tab and we're not connected, refresh the QR code
            socket.emit('requestNewQrCode');
        }
    });
});

// Function to show browser notifications
function showNotification(title, message) {
    // Check if the browser supports notifications
    if (!("Notification" in window)) {
        console.log("This browser does not support desktop notifications");
        return;
    }
    
    // Check if we already have permission
    if (Notification.permission === "granted") {
        createNotification(title, message);
    } 
    // Otherwise, ask for permission
    else if (Notification.permission !== "denied") {
        Notification.requestPermission().then(function (permission) {
            if (permission === "granted") {
                createNotification(title, message);
            }
        });
    }
    
    function createNotification(title, message) {
        const notification = new Notification(title, {
            body: message,
            icon: '/favicon.ico' // Add a favicon to your project for this
        });
        
        // Close the notification after 5 seconds
        setTimeout(() => notification.close(), 5000);
        
        // Focus on the window when notification is clicked
        notification.onclick = function() {
            window.focus();
            this.close();
        };
    }
} 