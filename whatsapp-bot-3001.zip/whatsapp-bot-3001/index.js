const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const csv = require('csv-parser');
const fs = require('fs');

// Path to your CSV file
const CSV_FILE_PATH = './contacts.csv';

// Initialize WhatsApp client
const client = new Client({
    authStrategy: new LocalAuth(),
    puppeteer: {
        headless: true,
    }
});

// Generate QR code for WhatsApp Web authentication
client.on('qr', (qr) => {
    console.log('QR RECEIVED. Scan this QR code with your WhatsApp:');
    qrcode.generate(qr, { small: true });
});

client.on('ready', () => {
    console.log('Client is ready! Starting to send messages...');
    sendMessagesToContacts();
});

// Function to read CSV and send messages
async function sendMessagesToContacts() {
    const contacts = [];
    
    // Read CSV file
    fs.createReadStream(CSV_FILE_PATH)
        .pipe(csv())
        .on('data', (row) => {
            contacts.push(row);
        })
        .on('end', async () => {
            console.log(`CSV file processed. Found ${contacts.length} contacts.`);
            
            // Send messages to each contact
            for (const contact of contacts) {
                try {
                    // Format phone number (remove spaces, ensure it has country code)
                    let phoneNumber = contact.phone || contact.phoneNumber || contact.number || contact['Phone Number'];
                    
                    // Standardize phone number format
                    phoneNumber = phoneNumber.replace(/\s+/g, '');
                    if (!phoneNumber.startsWith('+')) {
                        // Add default country code if not present (adjust as needed)
                        phoneNumber = '+' + phoneNumber;
                    }
                    
                    // Create personalized message using other fields in the CSV
                    let message = `Hello ${contact.name || 'there'}! `;
                    message += 'This is a customized message for you.';
                    
                    // Add any additional customization based on CSV fields
                    if (contact.company) {
                        message += ` We noticed you work at ${contact.company}.`;
                    }
                    
                    // Include a call to action
                    message += ' Would you like to know more about our services?';
                    
                    console.log(`Sending message to ${phoneNumber}...`);
                    
                    // Format the number for WhatsApp (country code + number without '+')
                    const formattedNumber = phoneNumber.substring(1) + '@c.us';
                    
                    // Send the message
                    await client.sendMessage(formattedNumber, message);
                    
                    console.log(`Message sent to ${phoneNumber} successfully!`);
                    
                    // Wait a bit between messages to avoid getting blocked
                    await new Promise(resolve => setTimeout(resolve, 3001));
                    
                } catch (error) {
                    console.error(`Failed to send message to ${contact.phone}: ${error.message}`);
                }
            }
            
            console.log('All messages have been sent!');
        });
}

// Initialize WhatsApp client
client.initialize(); 