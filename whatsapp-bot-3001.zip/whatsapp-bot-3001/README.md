# WhatsApp Bot for Customized Messages

This bot reads contact information from a CSV file and sends customized WhatsApp messages to each contact. It includes a web interface for easy management.

## Prerequisites

- Node.js installed on your system (or Docker if using containerized deployment)
- A WhatsApp account on your phone

## Installation

### Standard Installation

1. Clone this repository
2. Install dependencies
   ```
   npm install
   ```
3. Start the application
   ```
   npm start
   ```

### Docker Installation

1. Clone this repository
2. Build and start the Docker container
   ```
   docker-compose up -d
   ```
   
   Or build the Docker image manually
   ```
   docker build -t whatsapp-bot .
   docker run -p 3001:3001 -v $(pwd)/uploads:/usr/src/app/uploads -v $(pwd)/.wwebjs_auth:/usr/src/app/.wwebjs_auth whatsapp-bot
   ```

## CSV Format

The CSV file should have the following columns:
- `name`: Contact name
- `phone`: Phone number with country code (e.g., +1234567890)
- `company` (optional): Company name for additional customization

You can customize the message template in the web interface.

## How to Use

1. Open your browser and navigate to: `http://localhost:3001`
2. Use the web interface to:
   - Connect to WhatsApp by scanning the QR code
   - Upload your contacts CSV file
   - Customize your message template
   - Send messages to all contacts

## Web Interface Features

- **WhatsApp Connection**: Shows connection status and QR code for scanning
- **CSV Upload**: Easy upload of your contacts file
- **Contact Preview**: Shows a preview of the first 5 contacts in your CSV
- **Message Template**: Customize your message with placeholders:
  - `{{name}}` - Will be replaced with the contact's name
  - `{{company}}` - Will be replaced with company information if available
- **Sending Progress**: Real-time progress tracking for message sending
- **Auto-Reload**: Automatically handles session logouts and QR code refreshes

## Auto-Reload Feature

The application includes intelligent session management:

- **QR Code Expiry Countdown**: Shows how much time is left before the QR code expires
- **Automatic QR Refresh**: Automatically requests a new QR code when the current one expires
- **Session Logout Detection**: Automatically refreshes the page when WhatsApp logs out
- **Browser Notifications**: Receive notifications about connection status and message sending even when the browser tab is not active
- **Visibility Detection**: Automatically refreshes the QR code when you return to the tab after being away

## Docker Volumes

When running with Docker, two volumes are mounted:
- `./uploads`: For persisting uploaded CSV files
- `./.wwebjs_auth`: For persisting WhatsApp session data

## Notes

- The bot includes a delay of 3 seconds between messages to avoid getting blocked by WhatsApp
- Make sure your phone is connected to the internet while the bot is running
- For first-time recipients, WhatsApp may not deliver messages to numbers that haven't interacted with your account before
- The Docker container includes a health check endpoint at `/health` for monitoring the application status 