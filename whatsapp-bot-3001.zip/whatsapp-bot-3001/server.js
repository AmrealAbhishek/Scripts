const express = require('express');
const multer = require('multer');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode');
const csv = require('csv-parser');
const http = require('http');
const socketIo = require('socket.io');

// Initialize express app
const app = express();
const server = http.createServer(app);
const io = socketIo(server);
const port = 3001;

// Set up multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, './uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, 'contacts.csv');
  }
});

// Create uploads directory if it doesn't exist
if (!fs.existsSync('./uploads')) {
  fs.mkdirSync('./uploads');
}

// Initialize upload
const upload = multer({ 
  storage: storage,
  fileFilter: (req, file, cb) => {
    if(file.mimetype === 'text/csv') {
      cb(null, true);
    } else {
      cb(new Error('Only CSV files are allowed'));
    }
  }
});

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Variables for WhatsApp client
let whatsappClient = null;
let qrCodeImage = null;
let isClientReady = false;
let messageTemplate = 'Hello {{name}}! This is a customized message for you.{{company}}';
let lastQrGenerationTime = 0;
let isInitializing = false;

// Function to cleanly destroy WhatsApp client
async function destroyWhatsAppClient() {
  if (whatsappClient) {
    try {
      // Remove all listeners to prevent memory leaks
      whatsappClient.removeAllListeners();
      
      // Close puppeteer browser if it's open
      if (whatsappClient.pupBrowser) {
        await whatsappClient.pupBrowser.close();
      }
      
      console.log('WhatsApp client destroyed cleanly');
    } catch (error) {
      console.error('Error destroying WhatsApp client:', error);
    }
    
    whatsappClient = null;
    isClientReady = false;
  }
}

// Initialize WhatsApp client
function initializeWhatsAppClient() {
  // Prevent multiple initialization attempts
  if (isInitializing) return;
  isInitializing = true;
  
  console.log('Initializing WhatsApp client...');
  
  // Clean up existing client if any
  destroyWhatsAppClient().then(() => {
    whatsappClient = new Client({
      authStrategy: new LocalAuth(),
      puppeteer: {
        headless: true,
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-accelerated-2d-canvas',
          '--disable-gpu'
        ]
      }
    });

    whatsappClient.on('qr', async (qr) => {
      try {
        // Update QR generation time
        lastQrGenerationTime = Date.now();
        
        // Generate QR code as data URL
        qrCodeImage = await qrcode.toDataURL(qr);
        io.emit('qrCode', { qrCode: qrCodeImage });
        console.log('QR code generated at:', new Date().toISOString());
      } catch (err) {
        console.error('QR Code generation error:', err);
      }
    });

    whatsappClient.on('ready', () => {
      console.log('WhatsApp client is ready!');
      isClientReady = true;
      isInitializing = false;
      io.emit('clientStatus', { status: 'ready' });
    });

    whatsappClient.on('authenticated', () => {
      console.log('WhatsApp client authenticated');
      io.emit('clientStatus', { status: 'authenticated' });
    });

    whatsappClient.on('auth_failure', (msg) => {
      console.error('Authentication failure:', msg);
      isInitializing = false;
      io.emit('clientStatus', { status: 'authFailure', message: msg });
      
      // Reinitialize after a short delay
      setTimeout(initializeWhatsAppClient, 3001);
    });

    whatsappClient.on('disconnected', (reason) => {
      console.log('WhatsApp client disconnected:', reason);
      isClientReady = false;
      isInitializing = false;
      io.emit('clientStatus', { status: 'disconnected', reason: reason });
      
      // Reinitialize client after disconnection
      destroyWhatsAppClient().then(() => {
        setTimeout(initializeWhatsAppClient, 3001);
      });
    });

    // Initialize the client
    whatsappClient.initialize().catch(err => {
      console.error('Failed to initialize WhatsApp client:', err);
      isInitializing = false;
      
      // Try to reinitialize after a delay
      setTimeout(initializeWhatsAppClient, 5000);
    });
  });
}

// Routes
app.get('/favicon.ico', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'favicon.ico'));
});

app.get('/', (req, res) => {
  let contactsPreview = [];
  const csvPath = './uploads/contacts.csv';
  
  if (fs.existsSync(csvPath)) {
    const contacts = [];
    fs.createReadStream(csvPath)
      .pipe(csv())
      .on('data', (row) => {
        contacts.push(row);
      })
      .on('end', () => {
        // Just send the first 5 contacts for preview
        contactsPreview = contacts.slice(0, 5);
        res.render('index', { 
          qrCode: qrCodeImage,
          isClientReady: isClientReady,
          contacts: contactsPreview,
          messageTemplate: messageTemplate
        });
      });
  } else {
    res.render('index', { 
      qrCode: qrCodeImage,
      isClientReady: isClientReady,
      contacts: contactsPreview,
      messageTemplate: messageTemplate
    });
  }
});

// Upload CSV file
app.post('/upload', upload.single('csvFile'), (req, res) => {
  res.redirect('/');
});

// Update message template
app.post('/update-template', (req, res) => {
  messageTemplate = req.body.messageTemplate;
  res.redirect('/');
});

// Send messages to contacts
app.post('/send-messages', async (req, res) => {
  if (!isClientReady) {
    return res.status(400).json({ success: false, message: 'WhatsApp client not ready' });
  }

  const csvPath = './uploads/contacts.csv';
  if (!fs.existsSync(csvPath)) {
    return res.status(400).json({ success: false, message: 'No contacts file uploaded' });
  }

  // Start sending messages in the background
  sendMessagesToContacts(csvPath, messageTemplate);
  res.redirect('/');
});

// Function to read CSV and send messages
async function sendMessagesToContacts(csvFilePath, template) {
  const contacts = [];
  
  // Read CSV file
  fs.createReadStream(csvFilePath)
    .pipe(csv())
    .on('data', (row) => {
      contacts.push(row);
    })
    .on('end', async () => {
      io.emit('sendingProgress', { 
        total: contacts.length,
        current: 0,
        status: 'started' 
      });
      
      console.log(`CSV file processed. Found ${contacts.length} contacts.`);
      
      // Send messages to each contact
      let successCount = 0;
      let failureCount = 0;
      
      for (let i = 0; i < contacts.length; i++) {
        const contact = contacts[i];
        try {
          // Check if client is still ready before sending
          if (!isClientReady || !whatsappClient) {
            throw new Error('WhatsApp client disconnected during the operation');
          }
          
          // Format phone number (remove spaces, ensure it has country code)
          let phoneNumber = contact.phone || contact.phoneNumber || contact.number || contact['Phone Number'];
          
          if (!phoneNumber) {
            throw new Error('No phone number found for this contact');
          }
          
          // Standardize phone number format
          phoneNumber = phoneNumber.replace(/\s+/g, '');
          if (!phoneNumber.startsWith('+')) {
            // Add default country code if not present (adjust as needed)
            phoneNumber = '+' + phoneNumber;
          }
          
          // Create personalized message using template
          let message = template;
          
          // Replace {{name}} with the contact's name
          message = message.replace('{{name}}', contact.name || 'there');
          
          // Replace {{company}} with company info if available
          if (contact.company) {
            message = message.replace('{{company}}', ` We noticed you work at ${contact.company}.`);
          } else {
            message = message.replace('{{company}}', '');
          }
          
          // Format the number for WhatsApp (country code + number without '+')
          const formattedNumber = phoneNumber.substring(1) + '@c.us';
          
          console.log(`Sending message to ${phoneNumber}...`);
          io.emit('sendingProgress', { 
            total: contacts.length,
            current: i + 1,
            status: 'sending',
            phone: phoneNumber 
          });
          
          // Send the message
          await whatsappClient.sendMessage(formattedNumber, message);
          
          console.log(`Message sent to ${phoneNumber} successfully!`);
          successCount++;
          
          // Wait a bit between messages to avoid getting blocked
          await new Promise(resolve => setTimeout(resolve, 3001));
          
        } catch (error) {
          console.error(`Failed to send message to ${contact.phone}: ${error.message}`);
          failureCount++;
          io.emit('sendingProgress', { 
            status: 'error',
            phone: contact.phone || 'unknown',
            error: error.message
          });
          
          // If the client disconnected, stop the operation
          if (!isClientReady || !whatsappClient) {
            io.emit('sendingProgress', { 
              status: 'completed',
              total: contacts.length,
              success: successCount,
              failure: contacts.length - i + failureCount,
              error: 'WhatsApp session disconnected'
            });
            return;
          }
        }
      }
      
      io.emit('sendingProgress', { 
        status: 'completed',
        total: contacts.length,
        success: successCount,
        failure: failureCount
      });
      
      console.log(`All messages have been sent! Success: ${successCount}, Failure: ${failureCount}`);
    });
}

// Socket.io connection
io.on('connection', (socket) => {
  console.log('Client connected');
  
  // If client is already authenticated, emit status
  if (isClientReady) {
    socket.emit('clientStatus', { status: 'ready' });
  } else if (qrCodeImage) {
    socket.emit('qrCode', { qrCode: qrCodeImage });
  }
  
  // Handle request for new QR code
  socket.on('requestNewQrCode', () => {
    console.log('Client requested new QR code');
    
    // Only generate a new QR code if the previous one is older than 60 seconds
    // or if the client is not initialized yet
    const now = Date.now();
    if (!whatsappClient || !isInitializing || (now - lastQrGenerationTime > 60000)) {
      console.log('Reinitializing WhatsApp client to generate new QR code');
      initializeWhatsAppClient();
    } else {
      // If we recently generated a QR code, just send the existing one
      if (qrCodeImage) {
        socket.emit('qrCode', { qrCode: qrCodeImage });
      }
    }
  });
  
  socket.on('disconnect', () => {
    console.log('Client disconnected');
  });
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    whatsappStatus: isClientReady ? 'connected' : 'disconnected',
    timestamp: new Date().toISOString()
  });
});

// Create public directory if it doesn't exist
if (!fs.existsSync('./public')) {
  fs.mkdirSync('./public');
}

// Create favicon.ico if it doesn't exist
const faviconPath = path.join(__dirname, 'public', 'favicon.ico');
if (!fs.existsSync(faviconPath)) {
  // Copy a default favicon if available or create an empty one
  try {
    // Create an empty favicon file
    fs.writeFileSync(faviconPath, '');
    console.log('Created empty favicon.ico');
  } catch (err) {
    console.error('Failed to create favicon.ico:', err);
  }
}

// Initialize WhatsApp client on startup
initializeWhatsAppClient();

// Start server
server.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
}); 