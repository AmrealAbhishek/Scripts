#!/bin/bash

# Function to display help information
show_help() {
    echo "WhatsApp Bot Management Script"
    echo "Usage: ./manage.sh [command]"
    echo ""
    echo "Commands:"
    echo "  start       - Start the WhatsApp bot container"
    echo "  stop        - Stop the WhatsApp bot container"
    echo "  restart     - Restart the WhatsApp bot container"
    echo "  status      - Show the status of the container"
    echo "  logs        - Show container logs (use Ctrl+C to exit)"
    echo "  build       - Rebuild the Docker image"
    echo "  rebuild     - Rebuild and restart the container"
    echo "  help        - Show this help information"
}

# Check if Docker is available
if ! command -v docker &> /dev/null || ! command -v docker-compose &> /dev/null; then
    echo "Error: Docker and Docker Compose are required to run this script."
    echo "Please install Docker and Docker Compose first."
    exit 1
fi

# Create necessary directories if they don't exist
mkdir -p uploads
mkdir -p .wwebjs_auth

# Process commands
case "$1" in
    start)
        echo "Starting WhatsApp bot container..."
        docker-compose up -d
        echo "Container started. Web interface available at http://localhost:3001"
        ;;
    stop)
        echo "Stopping WhatsApp bot container..."
        docker-compose down
        echo "Container stopped."
        ;;
    restart)
        echo "Restarting WhatsApp bot container..."
        docker-compose restart
        echo "Container restarted."
        ;;
    status)
        echo "Container status:"
        docker-compose ps
        ;;
    logs)
        echo "Showing container logs (Ctrl+C to exit):"
        docker-compose logs -f
        ;;
    build)
        echo "Building Docker image..."
        docker-compose build
        echo "Build completed."
        ;;
    rebuild)
        echo "Rebuilding and restarting container..."
        docker-compose down
        docker-compose build
        docker-compose up -d
        echo "Container rebuilt and restarted."
        ;;
    help|"")
        show_help
        ;;
    *)
        echo "Unknown command: $1"
        show_help
        exit 1
        ;;
esac

exit 0 