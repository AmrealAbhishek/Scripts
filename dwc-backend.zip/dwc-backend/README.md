# Flask API Project

A modular Flask API project with centralized Blueprint structure, health check endpoint, and a robust Dark Web crawler with parallel processing and state persistence.

## Project Structure

```
app/
├── __init__.py            # Main application factory
├── crawler.py             # Dark Web crawler implementation
├── blueprints/            # All blueprints in one place
│   ├── __init__.py
│   ├── register.py        # Centralized blueprint registration
│   ├── api/               # API blueprint
│   │   ├── __init__.py    # Blueprint definition
│   │   └── routes.py      # API routes
│   ├── crawler/           # Crawler API blueprint
│   │   ├── __init__.py    # Blueprint definition
│   │   └── routes.py      # Crawler management endpoints
│   └── ...                # Other blueprints can be added here
└── ...
```

## Setup

1. Clone the repository
2. Create a virtual environment:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
4. Make sure MongoDB is installed and running
5. Set up a Tor proxy service on 127.0.0.1:9150 

## Running the Application

Start the development server:
```
python run.py
```

The server will be available at http://127.0.0.1:5001

## API Endpoints

### Health Check
- `GET /api/health` - Returns a status message indicating the API is working properly

### Crawler Management
- `POST /api/crawler/start` - Start the crawler
  - Request body (optional): 
    ```json
    {
      "urls": ["http://example.onion", "http://another.onion"],
      "resume": true
    }
    ```
    - `urls`: List of onion URLs to crawl (optional)
    - `resume`: Whether to resume from saved state (default: true)
- `POST /api/crawler/stop` - Stop the crawler and save state
- `GET /api/crawler/status` - Get current crawler status and metrics
- `GET /api/crawler/data?limit=10&skip=0` - Get crawled data with pagination
- `GET /api/crawler/detail/{url}` - Get detailed information about a specific URL

### Metadata Extractor
- `POST /api/crawler/extract` - Start the metadata extractor on crawled URLs
  - Request body (optional): 
    ```json
    {
      "resume": true
    }
    ```
    - `resume`: Whether to resume from saved state (default: true)
- `POST /api/crawler/extract/stop` - Stop the metadata extractor
- `GET /api/crawler/extract/status` - Get current metadata extractor status and metrics

## Crawler Features

### Parallel Processing
The crawler utilizes parallel processing with a thread pool to efficiently crawl multiple URLs simultaneously:

- Multiple worker threads (default: 3) process URLs in parallel
- Built-in thread safety with locks for shared data structures
- Smart workload distribution to maximize throughput
- Automatic circuit rotation to prevent Tor IP blocking

### State Persistence
The crawler maintains state persistence for reliable operation:

- Automatically saves state every 30 seconds during operation
- Complete state is saved when stopping the crawler
- Preserves both visited URLs and the queue of pending URLs
- Allows seamless resumption from where it left off
- State is stored in `crawler_state.pkl` file

### Metadata Extraction
The crawler includes a dedicated metadata extractor module that:

- Extracts detailed metadata from crawled onion URLs
- Captures page title, keywords, and meta descriptions
- Extracts full page content for analysis
- Collects image URLs found on pages
- Stores all extracted data in MongoDB
- Tracks extraction status to handle failures gracefully
- Extracts outbound links for further crawling

#### Advanced Extractor Features
The metadata extractor has been upgraded for better performance and reliability:

- Asynchronous processing with `asyncio` for high-throughput extraction
- Configurable concurrency with connection pooling
- Rate limiting to prevent overloading the Tor network
- Batch processing for efficient database operations
- Graceful shutdown handling for clean process termination
- Environment variable configuration for easy deployment
- Exponential backoff with smart retry logic
- Detailed metrics collection for monitoring
- State persistence with automatic saving and resumption

#### Extractor State Persistence

Similar to the crawler, the extractor maintains state persistence:

- Automatically saves state every 30 seconds during operation
- Preserves processed URLs and failure information 
- Tracks statistics for monitoring and reporting
- Allows resuming extraction from where it left off
- State is stored in `extractor_state.pkl` file

### Robust Connection Handling
- Automatic Tor circuit rotation after configurable number of requests
- Exponential backoff with retries for failed connections
- Content type filtering to avoid processing non-HTML content
- Smart error handling with detailed logging

## Configuration

The extractor can be configured using environment variables:

```
MAX_RETRIES=5                # Number of retry attempts
CONCURRENT_REQUESTS=10       # Maximum concurrent requests
RATE_LIMIT=3                 # Requests per second
BATCH_SIZE=50                # URLs to process in each batch
TOR_HOST=127.0.0.1           # Tor proxy host
TOR_PORT=9150                # Tor proxy port
TOR_CONTROL_PORT=9151        # Tor control port for identity rotation
TOR_CONTROL_PASSWORD=""      # Password for Tor control port
MONGODB_URI=mongodb://root:example@localhost:27017/
MONGODB_DB=dark_web_crawler
REQUEST_TIMEOUT=60           # Request timeout in seconds
IDENTITY_ROTATION=30         # Rotate Tor identity after this many requests
EXTRACTOR_STATE_FILE=extractor_state.pkl  # File to store extractor state
STATE_SAVE_INTERVAL=30       # Seconds between state saves
```

### Setting up Tor with Control Port

To enable Tor identity rotation, you need to configure the Tor control port:

1. Edit your `torrc` file (typically in `/etc/tor/torrc` or `~/Library/Application Support/tor/torrc`):

   ```
   ControlPort 9151
   HashedControlPassword your_hashed_password
   ```

2. Generate a hashed password using:
   ```
   tor --hash-password "your_password"
   ```

3. Set the environment variable `TOR_CONTROL_PASSWORD` to your chosen password.

The crawler reads initial URLs from a `urls.txt` file in the project root. Each URL should be on a separate line.

Key configuration settings in `app/crawler.py`:

```python
MAX_RETRIES = 5             # Number of retry attempts for connections
RETRY_DELAY = 3             # Base delay between retries in seconds
MAX_WORKERS = 3             # Number of parallel worker threads
TOR_CIRCUIT_RESET_INTERVAL = 10  # Request count before circuit reset
STATE_FILE = "crawler_state.pkl"  # File for state persistence
```

## Requirements

- Python 3.7+
- Flask
- MongoDB
- Tor proxy service
- Additional Python packages specified in requirements.txt:
  - requests
  - aiohttp
  - beautifulsoup4
  - pymongo
  - PySocks
  - backoff
  - aiolimiter 