import requests
import sys

def check_tor():
    """Check if Tor is running correctly"""
    print("Checking Tor connection...")
    
    # Configure session to use Tor
    session = requests.session()
    session.proxies = {
        'http': 'socks5h://127.0.0.1:9150',
        'https': 'socks5h://127.0.0.1:9150'
    }
    
    try:
        # Try to connect to the Tor check page
        response = session.get('https://check.torproject.org/')
        
        if 'Congratulations' in response.text:
            print("SUCCESS: Tor is working correctly!")
            return True
        else:
            print("WARNING: Connected through Tor, but verification failed")
            return False
    except Exception as e:
        print(f"ERROR: Could not connect via Tor: {e}")
        print("Please make sure Tor is running on 127.0.0.1:9150")
        return False

if __name__ == "__main__":
    result = check_tor()
    if not result:
        sys.exit(1) 