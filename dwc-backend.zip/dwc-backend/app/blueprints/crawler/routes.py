from flask import jsonify, request, render_template
from app.blueprints.crawler import crawler_bp
from app.crawler import (
    start_crawler, stop_crawler, get_crawler_status, 
    get_crawler_data, crawler_running
)
from app.extractor import (
    start_extractor, stop_extractor, get_extractor_status
)

@crawler_bp.route('/dashboard', methods=['GET'])
def dashboard():
    """Render the crawler dashboard UI"""
    return render_template('crawler_dashboard.html')

@crawler_bp.route('/start', methods=['POST'])
def start():
    """Start the crawler with optional URL list"""
    data = request.get_json() or {}
    urls = data.get('urls', None)
    
    success, message = start_crawler(urls)
    
    if success:
        return jsonify({"status": "success", "message": message}), 200
    else:
        return jsonify({"status": "error", "message": message}), 400

@crawler_bp.route('/stop', methods=['POST'])
def stop():
    """Stop the crawler"""
    success, message = stop_crawler()
    
    if success:
        return jsonify({"status": "success", "message": message}), 200
    else:
        return jsonify({"status": "error", "message": message}), 400

@crawler_bp.route('/status', methods=['GET'])
def status():
    """Get the crawler status"""
    return jsonify(get_crawler_status()), 200

@crawler_bp.route('/data', methods=['GET'])
def data():
    """Get the crawled data with pagination"""
    try:
        limit = int(request.args.get('limit', 10))
        skip = int(request.args.get('skip', 0))
    except ValueError:
        return jsonify({"error": "Invalid limit or skip parameters"}), 400
    
    data = get_crawler_data(limit, skip)
    return jsonify(data), 200

@crawler_bp.route('/detail/<path:url>', methods=['GET'])
def detail(url):
    """Get detailed data for a specific URL"""
    from pymongo import MongoClient
    try:
        # Connect to MongoDB
        client = MongoClient('mongodb://root:example@0.0.0.0:27017/')
        db = client['dark_web_crawler']
        urls_collection = db['onion_urls']
        
        # Find the document for this URL
        document = urls_collection.find_one({"url": url})
        
        if document:
            # Remove the content (which can be very large) and the MongoDB ID
            if "_id" in document:
                del document["_id"]
            
            # Return trimmed content preview if it exists
            if "content" in document:
                document["content_preview"] = document["content"][:500] + "..." if len(document["content"]) > 500 else document["content"]
                del document["content"]
                
            return jsonify(document), 200
        else:
            return jsonify({"error": "URL not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@crawler_bp.route('/extract', methods=['POST'])
def extract_metadata():
    """Start the metadata extractor on crawled onion URLs"""
    data = request.get_json() or {}
    resume = data.get('resume', True)  # Default to resuming from saved state
    
    success, message = start_extractor(resume=resume)
    
    if success:
        return jsonify({
            "status": "success",
            "message": message
        }), 200
    else:
        return jsonify({
            "status": "error",
            "message": message
        }), 400

@crawler_bp.route('/extract/stop', methods=['POST'])
def stop_metadata_extraction():
    """Stop the metadata extractor"""
    success, message = stop_extractor()
    
    if success:
        return jsonify({
            "status": "success",
            "message": message
        }), 200
    else:
        return jsonify({
            "status": "error",
            "message": message
        }), 400

@crawler_bp.route('/extract/status', methods=['GET'])
def get_extraction_status():
    """Get the current metadata extractor status"""
    return jsonify(get_extractor_status()), 200 