from flask import Blueprint

crawler_bp = Blueprint('crawler', __name__, url_prefix='/api/crawler') 

# Import routes at the bottom to avoid circular imports
from . import routes 