from flask import Flask

def register_blueprints(app: Flask):
    """Register all blueprints with the Flask application."""
    # Import blueprints - routes are imported within each blueprint's __init__.py
    from app.blueprints.api import api_bp
    from app.blueprints.crawler import crawler_bp
    
    # Register blueprints
    app.register_blueprint(api_bp)
    app.register_blueprint(crawler_bp) 