import requests
import aiohttp
import asyncio
from bs4 import BeautifulSoup
import time
import logging
import random
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, DuplicateKeyError
import backoff
import threading
from aiolimiter import AsyncLimiter
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Any, Union
import os
from contextlib import asynccontextmanager
import signal
import concurrent.futures
import functools
import sys
from aiohttp_socks import ProxyConnector
import pickle

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("extractor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Configuration - load from environment variables with defaults
MAX_RETRIES = int(os.environ.get("MAX_RETRIES", "5"))
RETRY_DELAY = int(os.environ.get("RETRY_DELAY", "3"))
CONCURRENT_REQUESTS = int(os.environ.get("CONCURRENT_REQUESTS", "10"))
RATE_LIMIT = float(os.environ.get("RATE_LIMIT", "3"))  # Requests per second
BATCH_SIZE = int(os.environ.get("BATCH_SIZE", "50"))
TOR_HOST = os.environ.get("TOR_HOST", "127.0.0.1")
TOR_PORT = int(os.environ.get("TOR_PORT", "9150"))
TOR_CONTROL_PORT = int(os.environ.get("TOR_CONTROL_PORT", "9151"))
TOR_CONTROL_PASSWORD = os.environ.get("TOR_CONTROL_PASSWORD", "")
MONGODB_URI = os.environ.get("MONGODB_URI", "mongodb://root:example@0.0.0.0:27017/")
MONGODB_DB = os.environ.get("MONGODB_DB", "dark_web_crawler")
REQUEST_TIMEOUT = int(os.environ.get("REQUEST_TIMEOUT", "60"))
IDENTITY_ROTATION = int(os.environ.get("IDENTITY_ROTATION", "30"))  # Rotate after this many requests
EXTRACTOR_STATE_FILE = os.environ.get("EXTRACTOR_STATE_FILE", "extractor_state.pkl")  # File to store extractor state
STATE_SAVE_INTERVAL = int(os.environ.get("STATE_SAVE_INTERVAL", "30"))  # Seconds between state saves

# Global state variables
extractor_running = False
extractor_task = None
stats_lock = asyncio.Lock()  # Lock for thread-safe operations on stats
save_state_timer = None  # Timer for periodic state saving

@dataclass
class ExtractorStats:
    """Data class for extractor statistics"""
    urls_processed: int = 0
    urls_succeeded: int = 0
    urls_failed: int = 0
    start_time: Optional[float] = None
    status: str = "stopped"
    runtime_seconds: Optional[float] = None
    in_progress_urls: List[str] = None
    
    def __post_init__(self):
        if self.in_progress_urls is None:
            self.in_progress_urls = []
            
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return asdict(self)

# Initialize stats
extractor_stats = ExtractorStats()

@dataclass
class ExtractorState:
    """Data class for extractor state persistence"""
    stats: ExtractorStats
    processed_urls: List[str] = None
    failed_urls: List[Dict[str, Any]] = None
    timestamp: float = 0.0
    
    def __post_init__(self):
        if self.processed_urls is None:
            self.processed_urls = []
        if self.failed_urls is None:
            self.failed_urls = []
        self.timestamp = time.time()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "stats": asdict(self.stats),
            "processed_urls": self.processed_urls,
            "failed_urls": self.failed_urls,
            "timestamp": self.timestamp
        }

def save_extractor_state():
    """Save extractor state to disk"""
    global extractor_stats
    
    try:
        # Create a state object with current stats and processed URLs
        with threading.Lock():  # Use threading lock for file operations
            # Get a copy of current stats
            stats_dict = asdict(extractor_stats)
            
            # Query MongoDB for processed URLs if available
            processed_urls = []
            failed_urls = []
            
            try:
                # Connect to MongoDB
                client = MongoClient(MONGODB_URI)
                db = client[MONGODB_DB]
                urls_collection = db['onion_urls']
                
                # Get successfully processed URLs
                processed = urls_collection.find(
                    {"metadata_extracted": True},
                    {"url": 1, "_id": 0}
                ).limit(1000)  # Limit to prevent excessive state file size
                
                processed_urls = [doc["url"] for doc in processed]
                
                # Get failed URLs with their error info
                failed = urls_collection.find(
                    {"metadata_extracted": False, "extraction_error": {"$exists": True}},
                    {"url": 1, "extraction_error": 1, "extraction_retries": 1, "_id": 0}
                ).limit(500)  # Limit to prevent excessive state file size
                
                failed_urls = list(failed)
                
                client.close()
            except Exception as e:
                logger.error(f"Error retrieving URL data for state save: {e}")
            
            # Create state object
            state = ExtractorState(
                stats=ExtractorStats(**stats_dict),
                processed_urls=processed_urls,
                failed_urls=failed_urls
            )
            
            # Save state to file
            with open(EXTRACTOR_STATE_FILE, 'wb') as f:
                pickle.dump(state, f)
                
            logger.info(f"Extractor state saved: {len(processed_urls)} processed URLs, {len(failed_urls)} failed URLs")
            return True
    except Exception as e:
        logger.error(f"Error saving extractor state: {e}")
        return False

def load_extractor_state():
    """Load extractor state from disk"""
    global extractor_stats
    
    if not os.path.exists(EXTRACTOR_STATE_FILE):
        logger.info("No saved extractor state found")
        return False
    
    try:
        with open(EXTRACTOR_STATE_FILE, 'rb') as f:
            state = pickle.load(f)
            
        # Set stats from saved state
        with threading.Lock():
            if isinstance(state, ExtractorState):
                # New format
                saved_stats = state.stats
                extractor_stats = ExtractorStats(**asdict(saved_stats))
                extractor_stats.status = "stopped"  # Always set to stopped on load
                
                logger.info(f"Extractor state loaded: {len(state.processed_urls)} processed URLs, {len(state.failed_urls)} failed URLs")
            else:
                # Handle old format or direct stats dictionary
                logger.warning("Loading from older state format")
                extractor_stats = ExtractorStats(**state)
                extractor_stats.status = "stopped"
        
        return True
    except Exception as e:
        logger.error(f"Error loading extractor state: {e}")
        return False

def schedule_state_save():
    """Schedule periodic state saving"""
    global save_state_timer
    
    if extractor_running:
        # Save state
        save_extractor_state()
        
        # Schedule next save
        save_state_timer = threading.Timer(STATE_SAVE_INTERVAL, schedule_state_save)
        save_state_timer.daemon = True
        save_state_timer.start()

@dataclass
class ExtractedMetadata:
    """Data class for extracted metadata"""
    title: str = ""
    keywords: str = ""
    description: str = ""
    content: str = ""
    image_urls: List[str] = None
    links: List[str] = None
    metadata_extracted: bool = True
    extraction_timestamp: float = 0.0
    extraction_status: str = "success"
    extraction_error: Optional[str] = None
    
    def __post_init__(self):
        if self.image_urls is None:
            self.image_urls = []
        if self.links is None:
            self.links = []
        self.extraction_timestamp = time.time()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return asdict(self)

async def connect_to_mongodb():
    """Establish connection to MongoDB with retry logic"""
    @backoff.on_exception(backoff.expo, 
                         ConnectionFailure,
                         max_tries=MAX_RETRIES)
    def try_connect():
        client = MongoClient(MONGODB_URI, 
                            serverSelectionTimeoutMS=5000,
                            connectTimeoutMS=5000)
        db = client[MONGODB_DB]
        # Test the connection
        client.admin.command('ping')
        return db, client

    try:
        logger.info("Connecting to MongoDB...")
        db, client = try_connect()
        logger.info("Successfully connected to MongoDB")
        return db, client
    except Exception as e:
        logger.critical(f"Failed to connect to MongoDB after multiple attempts: {e}")
        raise

@asynccontextmanager
async def get_aiohttp_session():
    """Create and manage an aiohttp session with Tor proxy"""
    # Create a SOCKS proxy connector for Tor
    connector = ProxyConnector.from_url(f'socks5://{TOR_HOST}:{TOR_PORT}', 
                                      limit=CONCURRENT_REQUESTS,  # Limit concurrent connections
                                      ssl=False,                  # Don't verify SSL for onion domains
                                      ttl_dns_cache=300           # Cache DNS results
                                     )
    
    timeout = aiohttp.ClientTimeout(total=REQUEST_TIMEOUT)
    
    async with aiohttp.ClientSession(
        connector=connector,
        timeout=timeout,
        headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; rv:91.0) Gecko/20100101 Firefox/91.0'
        }
    ) as session:
        yield session

@backoff.on_exception(backoff.expo, 
                     (aiohttp.ClientError, asyncio.TimeoutError),
                     max_tries=MAX_RETRIES)
async def fetch_url_async(url: str, session: aiohttp.ClientSession, rate_limiter: AsyncLimiter) -> Optional[str]:
    """Fetch a URL with retry logic using backoff decorator and rate limiting"""
    try:
        async with rate_limiter:
            logger.info(f"Fetching URL: {url}")
            # Make sure URL has the correct protocol prefix for onion services
            if '.onion/' in url and not url.startswith('http'):
                url = f"http://{url}"
                
            async with session.get(url, timeout=REQUEST_TIMEOUT) as response:
                if response.status != 200:
                    logger.warning(f"Non-200 status code ({response.status}) for {url}")
                    response.raise_for_status()
                return await response.text()
    except (aiohttp.ClientError, asyncio.TimeoutError) as e:
        logger.warning(f"Failed to fetch {url}: {e}")
        # Re-raise to let backoff handle retries
        raise
    except Exception as e:
        logger.error(f"Unexpected error fetching {url}: {e}")
        raise

async def extract_metadata_from_html(html: str, url: str) -> ExtractedMetadata:
    """Extract metadata from HTML content"""
    metadata = ExtractedMetadata()
    
    try:
        # Parse HTML with BeautifulSoup
        soup = BeautifulSoup(html, 'html.parser')
        
        # Get title
        if soup.find('title'):
            metadata.title = soup.find('title').text.strip()
        
        # Process all meta tags
        meta_tags = soup.find_all('meta')
        for tag in meta_tags:
            # Keywords
            if tag.get('name') == 'keywords' and tag.get('content'):
                metadata.keywords += tag.get('content', "")
                
            # Description
            if tag.get('name') == 'description' and tag.get('content'):
                metadata.description += tag.get('content', "")
        
        # Get content text
        if soup.find('body'):
            # Extract text while removing script and style content
            for script in soup(["script", "style"]):
                script.extract()
            metadata.content = soup.find('body').get_text(separator=' ', strip=True)
        
        # Get all image URLs
        for img in soup.find_all('img'):
            if img.get('src'):
                src = img.get('src')
                # Convert relative URLs to absolute
                if src.startswith('/'):
                    # Extract domain from URL
                    domain_parts = url.split('/')
                    if len(domain_parts) >= 3:
                        domain = '/'.join(domain_parts[:3])
                        src = domain + src
                metadata.image_urls.append(src)
        
        # Extract links for potential crawling
        for link in soup.find_all('a'):
            href = link.get('href')
            if href and not href.startswith('#') and not href.startswith('javascript:'):
                # Convert relative URLs to absolute
                if href.startswith('/'):
                    # Extract domain from URL
                    domain_parts = url.split('/')
                    if len(domain_parts) >= 3:
                        domain = '/'.join(domain_parts[:3])
                        href = domain + href
                elif not (href.startswith('http://') or href.startswith('https://')):
                    # Handle relative paths
                    base_url = '/'.join(url.split('/')[:-1])
                    href = f"{base_url}/{href}"
                    
                metadata.links.append(href)
                
        return metadata
    except Exception as e:
        logger.error(f"Error parsing HTML from {url}: {str(e)}")
        metadata.metadata_extracted = False
        metadata.extraction_status = "failed"
        metadata.extraction_error = str(e)
        return metadata

async def process_url(url: str, url_id: str, session: aiohttp.ClientSession, 
                     db, rate_limiter: AsyncLimiter) -> bool:
    """Process a single URL to extract metadata"""
    try:
        # Fetch the URL content
        html = await fetch_url_async(url, session, rate_limiter)
        if not html:
            raise Exception("Empty response received")
            
        # Extract metadata from the HTML
        metadata = await extract_metadata_from_html(html, url)
        
        # Update MongoDB with the extracted metadata
        urls_collection = db['onion_urls']
        result = urls_collection.update_one(
            {"_id": url_id},
            {"$set": metadata.to_dict()}
        )
        
        if result.modified_count > 0:
            logger.info(f"Successfully extracted and stored metadata for {url}")
            return True
        else:
            logger.warning(f"No document was updated for {url}")
            return False
            
    except Exception as e:
        logger.error(f"Error processing {url}: {str(e)}")
        # Mark as failed in the database
        try:
            urls_collection = db['onion_urls']
            urls_collection.update_one(
                {"_id": url_id},
                {"$set": {
                    "metadata_extracted": False,
                    "extraction_status": "failed",
                    "extraction_error": str(e),
                    "extraction_timestamp": time.time()
                }}
            )
        except Exception as db_error:
            logger.error(f"Failed to update failure status for {url}: {db_error}")
        return False

async def rotate_tor_identity():
    """Rotate the Tor identity by requesting a new circuit"""
    if not TOR_CONTROL_PASSWORD:
        logger.warning("Tor control password not set, skipping identity rotation")
        return False
        
    try:
        # Use telnet to communicate with Tor control port
        import telnetlib
        
        tn = telnetlib.Telnet(TOR_HOST, TOR_CONTROL_PORT, timeout=5)
        
        # Authenticate with control port
        tn.read_until(b"Escape character is '^]'.", timeout=5)
        tn.write(f"AUTHENTICATE \"{TOR_CONTROL_PASSWORD}\"\r\n".encode())
        response = tn.read_until(b"250 OK", timeout=5)
        
        if b"250 OK" not in response:
            logger.error(f"Failed to authenticate with Tor control port: {response}")
            return False
            
        # Request new identity
        tn.write(b"SIGNAL NEWNYM\r\n")
        response = tn.read_until(b"250 OK", timeout=5)
        
        if b"250 OK" not in response:
            logger.error(f"Failed to get new identity: {response}")
            return False
            
        tn.close()
        logger.info("Successfully rotated Tor identity")
        return True
    except Exception as e:
        logger.error(f"Error rotating Tor identity: {e}")
        return False

async def extract_metadata_async():
    """Extract metadata from URLs using async approach"""
    global extractor_stats, extractor_running
    
    async with stats_lock:
        extractor_stats = ExtractorStats(start_time=time.time(), status="running")
    
    db = None
    client = None
    request_counter = 0
    
    try:
        # Connect to MongoDB
        db, client = await connect_to_mongodb()
        urls_collection = db['onion_urls']
        
        # Configure rate limiter
        rate_limiter = AsyncLimiter(RATE_LIMIT, 1)  # Requests per second
        
        # Start the periodic state saving
        schedule_state_save()
        
        # Save initial state
        save_extractor_state()
        
        while extractor_running:
            try:
                # Rotate Tor identity periodically
                if request_counter >= IDENTITY_ROTATION:
                    logger.info(f"Rotating Tor identity after {request_counter} requests")
                    await rotate_tor_identity()
                    request_counter = 0
                    # Wait a moment for the circuit to establish
                    await asyncio.sleep(3)
                
                # Find URLs that haven't been processed or failed
                query = {"$or": [
                    {"metadata_extracted": {"$exists": False}},
                    {"metadata_extracted": False, "extraction_retries": {"$lt": MAX_RETRIES}}
                ]}
                projection = {"url": 1, "extraction_retries": 1}
                
                # Get a batch of URLs to process
                urls_to_process = list(urls_collection.find(query, projection).limit(BATCH_SIZE))
                
                if not urls_to_process:
                    logger.info("No more URLs to process, waiting for new URLs...")
                    await asyncio.sleep(30)  # Wait before checking again
                    continue
                    
                logger.info(f"Processing batch of {len(urls_to_process)} URLs")
                
                # Process URLs in parallel with concurrency control
                try:
                    async with get_aiohttp_session() as session:
                        tasks = []
                        for url_doc in urls_to_process:
                            # Check if we're still running before starting new tasks
                            if not extractor_running:
                                logger.info("Extractor stopping, cancelling pending tasks")
                                break
                                
                            # Increment retry counter before processing
                            url_id = url_doc["_id"]
                            retries = url_doc.get("extraction_retries", 0)
                            urls_collection.update_one(
                                {"_id": url_id},
                                {"$set": {"extraction_retries": retries + 1}}
                            )
                            
                            url = url_doc.get("url")
                            if not url:
                                continue
                                
                            # Create task for each URL
                            task = asyncio.create_task(
                                process_url(url, url_id, session, db, rate_limiter)
                            )
                            tasks.append(task)
                            
                            # Increment request counter for Tor identity rotation
                            request_counter += 1
                        
                        # Wait for all tasks to complete or until we're stopping
                        if tasks:
                            # Handle task completion and cancellation
                            done, pending = await asyncio.wait(
                                tasks, 
                                return_when=asyncio.ALL_COMPLETED,
                                timeout=REQUEST_TIMEOUT * 2  # Give tasks enough time to complete
                            )
                            
                            # Cancel any pending tasks if we're stopping
                            if not extractor_running and pending:
                                for task in pending:
                                    task.cancel()
                                
                                # Wait for cancellations to be acknowledged
                                if pending:
                                    await asyncio.wait(pending, timeout=5)
                            
                            # Process results
                            results = []
                            for task in done:
                                try:
                                    result = task.result()
                                    results.append(result)
                                except Exception as e:
                                    logger.error(f"Task error: {e}")
                                    results.append(False)
                                    
                            # Update stats
                            success_count = sum(1 for r in results if r is True)
                            fail_count = len(results) - success_count
                            
                            async with stats_lock:
                                extractor_stats.urls_processed += len(results)
                                extractor_stats.urls_succeeded += success_count
                                extractor_stats.urls_failed += fail_count
                            
                            logger.info(f"Batch completed: {success_count} succeeded, {fail_count} failed")
                except Exception as e:
                    logger.error(f"Error processing batch: {e}")
                    # Sleep a bit before the next attempt to avoid hammering services if there's an error
                    await asyncio.sleep(5)
                
                # Break if we're no longer running
                if not extractor_running:
                    logger.info("Extractor stopping as requested")
                    break
                    
                # Small delay between batches
                await asyncio.sleep(1)
            except asyncio.CancelledError:
                # Handle cancellation
                logger.info("Extraction process was cancelled")
                break
            except Exception as batch_error:
                # Log error but don't exit the loop - retry on next iteration
                logger.error(f"Error in batch processing: {batch_error}")
                await asyncio.sleep(10)  # Wait longer after an error
        
        logger.info("Metadata extraction completed")
        
    except Exception as e:
        logger.error(f"Error in metadata extraction process: {e}")
    finally:
        # Close MongoDB connection if open
        if client:
            client.close()
            
        # Update status to stopped
        async with stats_lock:
            extractor_stats.status = "stopped"
        extractor_running = False

async def run_extractor():
    """Run the metadata extractor"""
    logger.info("Starting metadata extractor")
    await extract_metadata_async()

def start_extractor(resume=True):
    """Start the metadata extractor"""
    global extractor_task, extractor_running, extractor_stats
    
    if extractor_running:
        return False, "Extractor is already running"
    
    # Set flag first to prevent race conditions
    extractor_running = True
    
    # Try to load saved state if resume is enabled
    if resume:
        load_extractor_state()
    else:
        # Reset stats
        extractor_stats = ExtractorStats()
    
    try:
        # Create a new event loop in a way that works with Flask
        loop = asyncio.new_event_loop()
        
        # Thread-local event loop setting
        def run_async_extractor():
            # Set the loop for this thread
            asyncio.set_event_loop(loop)
            
            # Signal handling only works in main thread
            import threading
            if threading.current_thread() is threading.main_thread():
                for sig in (signal.SIGINT, signal.SIGTERM):
                    try:
                        loop.add_signal_handler(sig, lambda s=sig: asyncio.create_task(shutdown(loop, sig)))
                    except RuntimeError as e:
                        logger.warning(f"Could not set signal handler: {e}")
            else:
                logger.info("Running in non-main thread, skipping signal handlers")
            
            try:
                # Start the main extraction coroutine
                loop.run_until_complete(run_extractor())
            except Exception as e:
                logger.error(f"Error in extraction process: {e}")
            finally:
                # Clean up
                pending_tasks = asyncio.all_tasks(loop)
                for task in pending_tasks:
                    task.cancel()
                
                # Wait for tasks to acknowledge cancellation
                if pending_tasks:
                    loop.run_until_complete(asyncio.gather(*pending_tasks, return_exceptions=True))
                
                loop.close()
                logger.info("Extractor event loop closed")
                
                # Save final state
                save_extractor_state()
                
                # Make sure we mark extractor as stopped
                global extractor_running
                extractor_running = False
        
        # Use a daemon thread for the extractor
        extractor_thread = threading.Thread(target=run_async_extractor, daemon=True)
        extractor_thread.start()
        
        logger.info("Metadata extractor started successfully")
        return True, "Metadata extractor started"
    except Exception as e:
        extractor_running = False
        logger.error(f"Failed to start extractor: {e}")
        return False, f"Failed to start extractor: {str(e)}"

async def shutdown(loop, signal=None):
    """Shutdown the extractor gracefully"""
    global extractor_running, save_state_timer
    
    if signal:
        logger.info(f"Received exit signal {signal.name}")
    else:
        logger.info("Shutting down extractor...")
    
    extractor_running = False
    
    # Cancel the state save timer if active
    if save_state_timer and save_state_timer.is_alive():
        save_state_timer.cancel()
    
    # Save state before shutdown
    save_extractor_state()
    
    async with stats_lock:
        extractor_stats.status = "stopping"
    
    # Wait for tasks to complete
    try:
        await asyncio.sleep(1)
    except asyncio.CancelledError:
        # Handle task cancellation
        pass
    
    # Only stop the event loop if it's still running
    if loop.is_running():
        loop.stop()
    
def stop_extractor():
    """Stop the metadata extractor"""
    global extractor_running, save_state_timer
    
    if not extractor_running:
        return False, "Extractor is not running"
    
    logger.info("Stopping metadata extractor...")
    
    # Cancel the state save timer if active
    if save_state_timer and save_state_timer.is_alive():
        save_state_timer.cancel()
    
    # Save state before stopping
    save_extractor_state()
    
    # Update flag to signal all processes to stop
    extractor_running = False
    
    # Update status synchronously for immediate feedback
    with threading.Lock():
        extractor_stats.status = "stopping"
    
    # Give it a moment to stop gracefully
    time.sleep(2)
    
    return True, "Metadata extractor is stopping"

async def get_extractor_status_async():
    """Get current extractor status asynchronously"""
    async with stats_lock:
        stats_copy = ExtractorStats(**asdict(extractor_stats))
        
        # Calculate runtime if the extractor has started
        if stats_copy.start_time:
            elapsed = time.time() - stats_copy.start_time
            stats_copy.runtime_seconds = elapsed
    
    return stats_copy

def get_extractor_status():
    """Get current extractor status"""
    # Create a synchronous wrapper around the async function
    loop = asyncio.new_event_loop()
    try:
        stats = loop.run_until_complete(get_extractor_status_async())
        
        # Convert to dict for adding additional info
        result = stats.to_dict()
        
        # Add information about saved state
        result["has_saved_state"] = os.path.exists(EXTRACTOR_STATE_FILE)
        if result["has_saved_state"]:
            try:
                result["state_last_modified"] = os.path.getmtime(EXTRACTOR_STATE_FILE)
                result["state_size_bytes"] = os.path.getsize(EXTRACTOR_STATE_FILE)
                
                # Try to get basic info from state file without full loading
                try:
                    with open(EXTRACTOR_STATE_FILE, 'rb') as f:
                        state = pickle.load(f)
                        if isinstance(state, ExtractorState):
                            result["state_processed_urls_count"] = len(state.processed_urls)
                            result["state_failed_urls_count"] = len(state.failed_urls)
                            result["state_timestamp"] = state.timestamp
                except Exception as e:
                    logger.warning(f"Error reading state file details: {e}")
            except:
                pass
        
        return result
    finally:
        loop.close()
    
if __name__ == "__main__":
    start_extractor() 