import requests
from bs4 import BeautifulSoup
import time
import random
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, DuplicateKeyError
import logging
import threading
from urllib.parse import urljoin
import os
import queue
from concurrent.futures import ThreadPoolExecutor
import concurrent.futures
import socket
import backoff
import json
import pickle
import signal

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crawler.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Configure Tor proxy session
MAX_RETRIES = 5  # Increased from 3
RETRY_DELAY = 3  # Increased from 2 seconds
MAX_WORKERS = 3  # Reduced from 5 to avoid overwhelming Tor
TOR_CIRCUIT_RESET_INTERVAL = 10  # Number of requests before requesting a new Tor circuit
STATE_FILE = "crawler_state.pkl"  # File to store crawler state

# Global variables to manage crawler state
crawler_running = False
url_queue = queue.Queue()
visited_urls = set()
url_lock = threading.Lock()  # Lock for thread-safe operations on shared data
crawler_stats = {
    "urls_visited": 0,
    "urls_queued": 0,
    "start_time": None,
    "status": "stopped",
    "active_workers": 0,
    "failed_urls": 0,
    "successful_urls": 0
}
stats_lock = threading.Lock()  # Lock for thread-safe operations on stats
save_state_timer = None  # Timer for periodic state saving
executor = None  # Global reference to the thread pool executor
active_workers = set()  # Keep track of active worker threads

# Condition to cancel backoff retries
def should_retry():
    """Check if retries should continue"""
    return crawler_running

# Use a shared session factory to create sessions for each thread
def create_tor_session():
    session = requests.session()
    session.proxies = {
        'http': 'socks5h://127.0.0.1:9150',
        'https': 'socks5h://127.0.0.1:9150'
    }
    # Set longer timeouts for Tor connections
    session.timeout = 30  # Increased timeout
    return session

# Check if Tor is running
def check_tor_connection():
    try:
        session = create_tor_session()
        response = session.get('https://check.torproject.org/', timeout=30)
        if 'Congratulations' in response.text:
            logger.info("Successfully connected to Tor network")
            return True
        else:
            logger.error("Connected to the proxy but not using Tor network")
            return False
    except Exception as e:
        logger.error(f"Failed to connect to Tor: {e}")
        return False

# Reset Tor circuit
def reset_tor_circuit():
    try:
        # Create a socket connection to the Tor control port
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect(('127.0.0.1', 9051))
        
        # Authenticate with the default password (empty password)
        # In production, you'd use actual authentication
        s.send(b'AUTHENTICATE ""\r\n')
        response = s.recv(1024)
        
        if b'250 OK' in response:
            # Send the SIGNAL NEWNYM command to request a new circuit
            s.send(b'SIGNAL NEWNYM\r\n')
            response = s.recv(1024)
            
            if b'250 OK' in response:
                logger.info("Successfully requested new Tor circuit")
                return True
        
        logger.warning("Failed to request new Tor circuit")
        return False
    except Exception as e:
        logger.error(f"Error resetting Tor circuit: {e}")
        return False
    finally:
        s.close()

def save_crawler_state():
    """Save crawler state to disk"""
    global visited_urls, crawler_stats
    
    try:
        with url_lock:
            # Get the remaining unprocessed URLs from the queue
            remaining_urls = list(visited_urls)
            queue_items = []
            
            # Save queue items without emptying the queue
            temp_queue = queue.Queue()
            while not url_queue.empty():
                try:
                    item = url_queue.get_nowait()
                    queue_items.append(item)
                    temp_queue.put(item)
                except queue.Empty:
                    break
                
            # Restore the queue
            while not temp_queue.empty():
                try:
                    url_queue.put(temp_queue.get_nowait())
                except queue.Empty:
                    break
            
            # Create state dictionary
            state = {
                "visited_urls": list(visited_urls),
                "queue_items": queue_items,
                "stats": crawler_stats.copy(),
                "timestamp": time.time()
            }
            
            # Save state to file
            with open(STATE_FILE, 'wb') as f:
                pickle.dump(state, f)
                
            logger.info(f"Crawler state saved: {len(visited_urls)} visited URLs, {len(queue_items)} queued URLs")
            return True
    except Exception as e:
        logger.error(f"Error saving crawler state: {e}")
        return False

def load_crawler_state():
    """Load crawler state from disk"""
    global visited_urls, crawler_stats, url_queue
    
    if not os.path.exists(STATE_FILE):
        logger.info("No saved state found")
        return False
    
    try:
        with open(STATE_FILE, 'rb') as f:
            state = pickle.load(f)
            
        with url_lock:
            # Initialize visited URLs
            visited_urls = set(state["visited_urls"])
            
            # Put queued items back in the queue
            for url in state["queue_items"]:
                url_queue.put(url)
            
            # Update stats
            with stats_lock:
                saved_stats = state["stats"]
                # Only copy relevant stats that should persist
                crawler_stats["urls_visited"] = len(visited_urls)
                crawler_stats["urls_queued"] = url_queue.qsize()
                crawler_stats["failed_urls"] = saved_stats.get("failed_urls", 0)
                crawler_stats["successful_urls"] = saved_stats.get("successful_urls", 0)
        
        logger.info(f"Crawler state loaded: {len(visited_urls)} visited URLs, {url_queue.qsize()} queued URLs")
        return True
    except Exception as e:
        logger.error(f"Error loading crawler state: {e}")
        return False

def schedule_state_save():
    """Schedule periodic state saving"""
    global save_state_timer
    
    if crawler_running:
        # Save state
        save_crawler_state()
        
        # Schedule next save
        save_state_timer = threading.Timer(30.0, schedule_state_save)
        save_state_timer.daemon = True
        save_state_timer.start()

def connect_to_mongodb():
    """Establish connection to MongoDB with retry logic"""
    @backoff.on_exception(backoff.expo, 
                         ConnectionFailure,
                         max_tries=MAX_RETRIES,
                         giveup=lambda e: not should_retry())
    def try_connect():
        # Update with your MongoDB connection details
        client = MongoClient('mongodb://root:example@0.0.0.0:27017/', 
                            serverSelectionTimeoutMS=5000,
                            connectTimeoutMS=5000)
        db = client['dark_web_crawler']
        # Test the connection
        client.admin.command('ping')
        return db

    try:
        logger.info("Connecting to MongoDB...")
        db = try_connect()
        logger.info("Successfully connected to MongoDB")
        return db
    except Exception as e:
        logger.critical(f"Failed to connect to MongoDB after multiple attempts: {e}")
        raise

@backoff.on_exception(backoff.expo, 
                     requests.exceptions.RequestException,
                     max_tries=MAX_RETRIES,
                     giveup=lambda e: not should_retry())
def fetch_url(url, session, circuit_count=0):
    """Fetch a URL with retry logic using backoff decorator"""
    if not crawler_running:
        logger.info(f"Crawler is stopping, cancelling fetch for {url}")
        raise Exception("Crawler stopping")
        
    try:
        # Check if we need to request a new Tor circuit
        if circuit_count > 0 and circuit_count % TOR_CIRCUIT_RESET_INTERVAL == 0:
            logger.info(f"Requesting new Tor circuit after {circuit_count} requests")
            reset_tor_circuit()
            # Give Tor time to establish new circuit
            time.sleep(2)
        
        logger.info(f"Fetching URL: {url}")
        response = session.get(url, timeout=30)  # Increased timeout
        response.raise_for_status()
        
        with stats_lock:
            crawler_stats["successful_urls"] += 1
            
        return response
    except requests.exceptions.RequestException as e:
        with stats_lock:
            crawler_stats["failed_urls"] += 1
        logger.warning(f"Failed to fetch {url}: {e}")
        # Re-raise to let backoff handle retries
        raise

def is_onion_url(url):
    """Check if a URL is a valid .onion URL"""
    return url and '.onion' in url and (url.startswith('http://') or url.startswith('https://'))

def normalize_url(url, base_url):
    """Normalize and clean URLs"""
    if not url:
        return None
    
    # Handle relative URLs
    if not url.startswith(('http://', 'https://')):
        url = urljoin(base_url, url)
    
    # Remove fragments
    url = url.split('#')[0]
    
    # Remove query parameters for better deduplication (optional)
    # url = url.split('?')[0]
    
    # Remove trailing slash for consistency
    if url.endswith('/'):
        url = url[:-1]
        
    return url

def process_url(url, db, urls_collection, circuit_count):
    """Process a single URL, extract links, and update database"""
    # Register this thread as active
    thread_id = threading.get_ident()
    with stats_lock:
        active_workers.add(thread_id)
        crawler_stats["active_workers"] = len(active_workers)
    
    try:
        # Check early if crawler is still running
        if not crawler_running:
            logger.info(f"Crawler stopping, skipping processing of {url}")
            return []
            
        session = create_tor_session()
        
        # Skip URLs that have already been visited
        with url_lock:
            if url in visited_urls:
                return []
            visited_urls.add(url)
            with stats_lock:
                crawler_stats["urls_visited"] = len(visited_urls)
        
        # Make a request to the URL
        try:
            response = fetch_url(url, session, circuit_count)
            if not response:
                return []
        except Exception as e:
            logger.error(f"Failed to fetch {url} after multiple retries: {e}")
            return []
        
        # Check again if crawler is still running
        if not crawler_running:
            logger.info(f"Crawler stopping, abandoning processing of {url}")
            return []
            
        # Insert the URL into MongoDB
        try:
            urls_collection.insert_one({
                "url": url, 
                "timestamp": time.time(),
                "status_code": response.status_code,
                "content_type": response.headers.get('Content-Type', 'unknown')
            })
            logger.info(f"Added to database: {url}")
        except DuplicateKeyError:
            logger.debug(f"URL already in database: {url}")
            # Update the entry to show we revisited it
            urls_collection.update_one(
                {"url": url},
                {"$set": {"last_visited": time.time()}}
            )
        
        # Check again if crawler is still running
        if not crawler_running:
            logger.info(f"Crawler stopping, skipping content extraction for {url}")
            return []
            
        # Parse the HTML content of the response using BeautifulSoup
        new_urls = []
        try:
            # Only process HTML content
            content_type = response.headers.get('Content-Type', '').lower()
            if 'text/html' not in content_type and 'application/xhtml' not in content_type:
                logger.debug(f"Skipping non-HTML content: {content_type} for {url}")
                return []
                
            soup = BeautifulSoup(response.content, "html.parser")
            
            # Extract page title and content
            title = soup.title.string if soup.title else "No Title"
            
            # Update the document with title and content
            urls_collection.update_one(
                {"url": url},
                {"$set": {"title": title, "content_hash": hash(str(soup)), "extracted_at": time.time()}}
            )
            
            # Find all links on the page
            links = soup.find_all("a")
            
            # Add any new links to the list of URLs to visit
            for link in links:
                href = link.get("href")
                normalized_url = normalize_url(href, url)
                
                if normalized_url and is_onion_url(normalized_url):
                    with url_lock:
                        if normalized_url not in visited_urls:
                            new_urls.append(normalized_url)
                            logger.debug(f"Found new URL: {normalized_url}")
            
            return new_urls
        except Exception as e:
            logger.error(f"Error parsing content from {url}: {e}")
            return []
            
    except Exception as e:
        logger.error(f"Error processing URL {url}: {e}")
        return []
    finally:
        # Unregister this thread from active workers
        with stats_lock:
            active_workers.discard(thread_id)
            crawler_stats["active_workers"] = len(active_workers)

def crawler_manager():
    """Manage the crawling process using a thread pool"""
    global crawler_stats, crawler_running, executor
    
    logger.info("Starting crawler manager")
    
    # Check Tor connection before starting
    if not check_tor_connection():
        logger.error("Cannot connect to Tor network. Please ensure Tor is running.")
        crawler_running = False
        with stats_lock:
            crawler_stats["status"] = "error"
            crawler_stats["error"] = "Cannot connect to Tor network"
        return
    
    try:
        # Connect to MongoDB
        db = connect_to_mongodb()
        urls_collection = db['onion_urls']
        
        # Create an index on the url field for faster lookups and to enforce uniqueness
        urls_collection.create_index("url", unique=True)
        
        # Circuit request counter
        circuit_count = 0
        
        # Update status to running
        with stats_lock:
            crawler_stats["status"] = "running"
        
        # Start the periodic state saving
        schedule_state_save()
        
        # Force an immediate state save
        save_crawler_state()
        
        # Create a thread pool
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor_instance:
            executor = executor_instance  # Store global reference
            future_to_url = {}
            
            # Process URLs until stopped or queue is empty
            while crawler_running:
                # Start new tasks if we have capacity and URLs in the queue
                while len(future_to_url) < MAX_WORKERS and not url_queue.empty() and crawler_running:
                    try:
                        url = url_queue.get_nowait()
                        circuit_count += 1
                        future = executor.submit(process_url, url, db, urls_collection, circuit_count)
                        future_to_url[future] = url
                    except queue.Empty:
                        break
                
                # Check for completed tasks with a short timeout
                try:
                    # Get only the COMPLETED futures - don't wait for all to complete
                    completed = concurrent.futures.wait(
                        future_to_url.keys(),
                        timeout=0.5,
                        return_when=concurrent.futures.FIRST_COMPLETED
                    )
                    
                    # Handle completed futures
                    for future in completed.done:
                        url = future_to_url.pop(future)
                        try:
                            new_urls = future.result()
                            # Add new URLs to the queue
                            for new_url in new_urls:
                                url_queue.put(new_url)
                            with stats_lock:
                                crawler_stats["urls_queued"] = url_queue.qsize()
                        except Exception as e:
                            logger.error(f"Error processing {url}: {e}")
                except Exception as e:
                    logger.error(f"Error waiting for futures: {e}")
                
                # If we have no active tasks and the queue is empty, we're done
                if not future_to_url and url_queue.empty():
                    logger.info("No more URLs to process and no active tasks")
                    break
                
                # If crawler is stopping but we have pending futures, wait for them with timeout
                if not crawler_running and future_to_url:
                    logger.info(f"Crawler stopping, waiting for {len(future_to_url)} active tasks to complete...")
                    try:
                        # Wait with a reasonable timeout for remaining tasks
                        completed = concurrent.futures.wait(
                            future_to_url.keys(),
                            timeout=2.0,  # Reduced timeout for stopping
                            return_when=concurrent.futures.ALL_COMPLETED
                        )
                        
                        # If any tasks still remain, cancel them
                        if len(completed.not_done) > 0:
                            logger.warning(f"Cancelling {len(completed.not_done)} tasks that did not complete in time")
                            for future in completed.not_done:
                                future.cancel()
                                
                            # Clear all active futures
                            future_to_url.clear()
                    except Exception as e:
                        logger.error(f"Error waiting for remaining futures: {e}")
                    break
                    
                # Short sleep to prevent CPU spinning
                time.sleep(0.1)
                
    except Exception as e:
        logger.error(f"Unexpected error in crawler_manager: {e}")
    finally:
        # Save state on exit
        save_crawler_state()
        
        # Cancel timer if active
        if save_state_timer and save_state_timer.is_alive():
            save_state_timer.cancel()
        
        # Clear the executor reference
        executor = None
        
        # Clear active workers
        with stats_lock:
            active_workers.clear()
            
        logger.info(f"Crawler manager stopped. Visited {len(visited_urls)} URLs.")
        with stats_lock:
            crawler_stats["status"] = "stopped"
            crawler_stats["active_workers"] = 0
        crawler_running = False

def stop_crawler():
    """Stop the crawler"""
    global crawler_running, crawler_stats, save_state_timer, executor
    
    if not crawler_running:
        return False, "Crawler is not running"
    
    logger.info("Stopping crawler...")
    
    # Set the stopping flag first
    crawler_running = False
    with stats_lock:
        crawler_stats["status"] = "stopping"
    
    # Cancel the state save timer if active
    if save_state_timer and save_state_timer.is_alive():
        save_state_timer.cancel()
    
    # Trigger immediate state save
    save_crawler_state()
    
    # Shutdown executor immediately if it exists
    if executor:
        logger.info("Shutting down executor...")
        try:
            # This will cancel all pending futures
            executor.shutdown(wait=False)
        except Exception as e:
            logger.error(f"Error shutting down executor: {e}")
    
    # Create a thread to monitor and force crawler shutdown if it takes too long
    def force_shutdown():
        # Wait for a reasonable amount of time for graceful shutdown
        time.sleep(5)  # Reduced from 10s to 5s for faster response
        
        # Force threads to terminate
        if active_workers:
            logger.warning(f"Force terminating {len(active_workers)} active worker threads")
            with stats_lock:
                active_workers.clear()
                crawler_stats["active_workers"] = 0
        
        # If still in stopping state, force to stopped
        with stats_lock:
            if crawler_stats["status"] == "stopping":
                logger.warning("Forcing crawler to stopped state after timeout")
                crawler_stats["status"] = "stopped"
                
    shutdown_thread = threading.Thread(target=force_shutdown)
    shutdown_thread.daemon = True
    shutdown_thread.start()
    
    return True, "Crawler is stopping and state has been saved"

def start_crawler(urls=None, resume=True):
    """Start the crawler with multiple URLs, with option to resume from saved state"""
    global crawler_running, crawler_stats, url_queue, visited_urls, active_workers
    
    if crawler_running:
        return False, "Crawler is already running"
    
    # Clear active workers on start
    with stats_lock:
        active_workers.clear()
    
    # Check if we should try to resume
    resumed = False
    if resume:
        resumed = load_crawler_state()
    
    # If not resuming or resume failed, initialize with new URLs
    if not resumed:
        if not urls:
            # Try to read URLs from file
            try:
                with open('urls.txt', 'r') as f:
                    urls = [url.strip() for url in f.read().splitlines() if url.strip()]
            except FileNotFoundError:
                # If file not found, create it with a default URL
                urls = ["http://zqktlwiuavvvqqt4ybvgvi7tyo4hjl5xgfuvpdf6otjiycgwqbym2qad.onion"]
                with open('urls.txt', 'w') as f:
                    f.write(urls[0] + '\n')
        
        if not urls:
            return False, "No URLs provided and urls.txt is empty or not found"
        
        # Reset state
        url_queue = queue.Queue()
        visited_urls = set()
        
        # Add all initial URLs to the queue
        valid_urls = 0
        for url in urls:
            if url and is_onion_url(url):
                url_queue.put(url)
                valid_urls += 1
        
        if valid_urls == 0:
            return False, "No valid .onion URLs provided"
        
        # Reset stats
        crawler_stats = {
            "urls_visited": 0,
            "urls_queued": url_queue.qsize(),
            "start_time": time.time(),
            "status": "starting",
            "active_workers": 0,
            "failed_urls": 0,
            "successful_urls": 0
        }
    
    # First check if Tor is running
    if not check_tor_connection():
        return False, "Cannot connect to Tor network. Please ensure Tor is running."
    
    crawler_running = True
    
    # Start the crawler manager in a separate thread
    crawler_thread = threading.Thread(target=crawler_manager)
    crawler_thread.daemon = True
    crawler_thread.start()
    
    if resumed:
        return True, f"Crawler resumed with {url_queue.qsize()} queued URLs and {len(visited_urls)} already visited"
    else:
        return True, f"Crawler started successfully with {url_queue.qsize()} URLs"

def get_crawler_status():
    """Get the current status of the crawler"""
    global crawler_stats
    
    with stats_lock:
        # Make a copy to avoid race conditions
        stats_copy = crawler_stats.copy()
        
        # Calculate runtime if the crawler has started
        if stats_copy["start_time"]:
            elapsed = time.time() - stats_copy["start_time"]
            stats_copy["runtime_seconds"] = elapsed
            
        # Update queue size
        stats_copy["urls_queued"] = url_queue.qsize()
        
        # Add information about saved state
        stats_copy["has_saved_state"] = os.path.exists(STATE_FILE)
        if stats_copy["has_saved_state"]:
            try:
                stats_copy["state_last_modified"] = os.path.getmtime(STATE_FILE)
            except:
                pass
    
    return stats_copy

def get_crawler_data(limit=10, skip=0):
    """Get the data that has been crawled"""
    try:
        db = connect_to_mongodb()
        urls_collection = db['onion_urls']
        
        # Count total documents
        total = urls_collection.count_documents({})
        
        # Get the documents with pagination
        data = list(urls_collection.find(
            {}, 
            {"url": 1, "title": 1, "timestamp": 1, "status_code": 1, "_id": 0}
        ).sort("timestamp", -1).skip(skip).limit(limit))
        
        return {
            "total": total,
            "data": data,
            "page": {
                "limit": limit,
                "skip": skip
            }
        }
    except Exception as e:
        logger.error(f"Error getting crawler data: {e}")
        return {
            "error": str(e),
            "total": 0,
            "data": []
        } 