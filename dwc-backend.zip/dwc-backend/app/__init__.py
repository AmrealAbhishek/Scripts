from flask import Flask, redirect, url_for

def create_app():
    app = Flask(__name__)
    
    # Register all blueprints from centralized location
    from app.blueprints.register import register_blueprints
    register_blueprints(app)
    
    # Add a redirect from root to crawler dashboard
    @app.route('/')
    def index():
        return redirect(url_for('crawler.dashboard'))
    
    return app 