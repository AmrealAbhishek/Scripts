# API Usage Examples

## Start the Crawler
```bash
curl -X POST http://localhost:5001/api/crawler/start \
  -H "Content-Type: application/json" \
  -d '{"urls": ["http://zqktlwiuavvvqqt4ybvgvi7tyo4hjl5xgfuvpdf6otjiycgwqbym2qad.onion"]}'
```

## Check Crawler Status
```bash
curl http://localhost:5001/api/crawler/status
```

## Stop the Crawler
```bash
curl -X POST http://localhost:5001/api/crawler/stop
```

## Get Crawled Data (with pagination)
```bash
curl http://localhost:5001/api/crawler/data?limit=10&skip=0
```

## Get Details for a Specific URL
```bash
# URL must be URL-encoded
curl http://localhost:5001/api/crawler/detail/http%3A%2F%2Fzqktlwiuavvvqqt4ybvgvi7tyo4hjl5xgfuvpdf6otjiycgwqbym2qad.onion
```

## Health Check
```bash
curl http://localhost:5001/api/health
``` 